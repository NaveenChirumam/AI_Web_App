<style>
	.bibliography {
		padding: 20px;
		border: 1px solid #ccc;
		border-radius: 10px;
		margin: 20px;
	}
	.bibliography h3 {
		font-size: 1.2em;
		margin-top: 0;
	}
	.bibliography ul {
		margin: 0;
		padding: 0;
		list-style: none;
	}
	.bibliography li {
		margin-bottom: 10px;
	}
</style>

<div class="super_container">
	<!-- layout -->
    <?php 
        page_extends("app.layout");
    ?>
    <!-- /layout -->
    
	<!-- Home -->
	<div class="home">
		<div class="home_background parallax-window" data-parallax="scroll" data-image-src="<?= asset_path("storage/images/about.jpg") ?>" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content">
							<div class="home_title">About <span>NAVEENAI</span></div>
							<div class="breadcrumbs">
								<ul>
									<li><a href="#">Home</a></li>
									<li>About NAVEENAI</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- About -->

	<div class="row">
		<div class="col-lg-4">
			<div class="card">
			<div class="card-body">
				<li style="font-size: 24px;">
					<a href="/about-us">
						<i class="fas fa-info-circle"></i>
						<span>Aims and Scope</span>
					</a>
				</li> 
				<div class="bibliography pt-5">  
					<h3 style="font-size: 24px;"><i class="fas fa-handshake"></i> <u>Bibliographic References</u></h3> 
					<ul>
						<li>
							<strong>Rajkomar, A., Oren, E., Chen, K., et al.</strong> "Deep learning for healthcare decision making with EMR data." NPJ Digital Medicine, 2018.
							<a href="https://www.nature.com/articles/s41746-018-0029-1">Read Here</a>
						</li>
						<li>
							<strong>Price, W. N., & Gerke, S.</strong> "Artificial intelligence in health care: Anticipating challenges to ethics." Journal of Medical Artificial Intelligence, 2019.
							<a href="https://pubmed.ncbi.nlm.nih.gov/31674282/">Read Here</a>
						</li>
						<li>
							<strong>Beam, A. L., & Kohane, I. S.</strong> "Artificial intelligence in clinical health care applications: Viewpoint." JAMA, 2016.
							<a href="https://jamanetwork.com/journals/jama/fullarticle/2578827">Read Here</a>
						</li>
						<li>
							<strong>Sivarajah, U., Kamal, M. M., Irani, Z., & Weerakkody, V.</strong> "Artificial intelligence in medicine: Applications, implications, and limitations." Yearbook of Medical Informatics, 2019.
							<a href="https://jamanetwork.com/journals/jama/fullarticle/2578827">Read Here</a>
						</li>
						<li>
							<strong>Kotsiantis, S. B., Zaharakis, I. D., & Pintelas, P. E.</strong> "Machine learning for medical diagnosis: history, state of the art and perspective." Artificial Intelligence in Medicine, 2006.
							<a href="https://www.sciencedirect.com/science/article/abs/pii/S0933365706000251">Read Here</a>
						</li>
					</ul>
				</div>  
			</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="card">
			<div class="card-body">
				<div class="aims-and-scope"> 
					<h4 class="card-title"><u>Aims and Scope</u></h4>
					<p>
					Artificial Intelligence in Medicine publishes original articles from a wide variety of interdisciplinary perspectives concerning the theory and practice of artificial intelligence (AI) in medicine, medically-oriented human biology, and health care.
					</p>
					<p>
					Artificial intelligence in medicine may be characterized as the scientific discipline pertaining to research studies, projects, and applications that aim at supporting decision-based medical tasks through knowledge- and/or data-intensive computer-based solutions that ultimately support and improve the performance of a human care provider.
					</p>
					<p>
					Artificial Intelligence in Medicine considers for publication manuscripts that have both:
					</p>
					<ul>
					<li>Potential high impact in some medical or healthcare domain;</li>
					<li>Strong novelty of method and theory related to AI and computer science techniques.</li>
					</ul>
					<p>
					Artificial Intelligence in Medicine papers must refer to real-world medical domains, considered and discussed at the proper depth, from both the technical and the medical points of view. The inclusion of a clinical assessment of the usefulness and potential impact of the submitted work is strongly recommended.
					</p>
				</div>
				</div>

				<div class="card">
				<div class="card-body">
					<h4 class="card-title">Focus Areas</h4>
					<ul>
					<li>AI-based clinical decision making;</li>
					<li>Medical knowledge engineering;</li>
					<li>Knowledge-based and agent-based systems;</li> 
					</ul>
				</div>
				</div> 
			</div> 
			</div>
			</div>
		</div>
	</div> 

    <!-- footer -->
    <?php 
        page_extends("app.footer");
    ?>
    <!-- /footer -->
</div>
