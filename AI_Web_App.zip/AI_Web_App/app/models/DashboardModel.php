<?php

namespace App\models;

use SelfPhp\SP;

class DashboardModel extends SP
{
    public static $table = 'users';

    public function __construct()
    {
        
    }
}
