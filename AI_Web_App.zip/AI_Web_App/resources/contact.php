

<!-- body -->
<div class="super_container">
    <!-- layout -->
    <?php 
        page_extends("app.layout");
    ?>
    <!-- /layout -->
    
	<!-- Home -->
	<div class="home">
		<div class="home_background parallax-window" data-parallax="scroll" data-image-src="<?= asset_path("storage/images/contact.jpg") ?>" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content"> 
							<div class="breadcrumbs">
								<ul>
									<li style="font-size: 24px"><a href="#">Home</a></li>
									<li style="font-size: 24px">Contact</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Contact -->
	<div class="contact">
		<div class="container">
			<div class="row">
				<!-- Contact Info -->
				<div class="col-lg-6">
					<div class="section_title"><h2>Get in touch</h2></div>
					<div class="contact_text">
                        <p>
                            Connect with us and let's shape a healthier tomorrow together. Your thoughts, questions, 
                            and aspirations matter. Reach out, and let's start a conversation that could be the 
                            beginning of a positive transformation in your healthcare journey.
                        </p>
                    </div>
					<ul class="contact_about_list">
						<li><div class="contact_about_icon"><img src="<?= asset_path("storage/images/phone-call.svg") ?>" alt=""></div><span>+1 (857) 701-3596</span></li>
						<li><div class="contact_about_icon"><img src="<?= asset_path("storage/images/envelope.svg") ?>" alt=""></div><span>info.naveenai.com</span></li>
						<li><div class="contact_about_icon"><img src="<?= asset_path("storage/images/placeholder.svg") ?>" alt=""></div><span>NAVEENAi Headquarters, Menlo Park, CA 94025</span></li>
					</ul>
				</div>

				<!-- Contact Form -->
				<div class="col-lg-6 form_col">
					<div class="contact_form_container">
						<form action="#" id="contact_form" class="contact_form">
							<div class="row">
								<div class="col-md-6 input_col">
									<div class="input_container input_name"><input type="text" class="contact_input" placeholder="Name" required="required"></div>
								</div>
								<div class="col-md-6 input_col">
									<div class="input_container"><input type="email" class="contact_input" placeholder="E-mail" required="required"></div>
								</div>
							</div>
							<div class="input_container"><input type="text" class="contact_input" placeholder="Subject" required="required"></div>
							<div class="input_container"><textarea class="contact_input contact_text_area" placeholder="Message" required="required"></textarea></div>
							<button class="button contact_button"><a href="#">send</a></button>
						</form>
					</div>
				</div>
			</div> 
		</div>
	</div>
</div> 
<!-- /body -->

<!-- footer -->
<?php 
    page_extends("app.footer");
?>
<!-- /footer -->