<?php

namespace App\models;

use SelfPhp\SP;

class BlogsNewsModel extends SP {
    
}