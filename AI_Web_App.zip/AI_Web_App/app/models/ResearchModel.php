<?php

namespace App\models;

use SelfPhp\SP;

class ServicesModel extends SP {
    
}