
        <!-- Footer -->
        <footer class="footer">
            <div class="footer_container">
                <div class="container">
                    <div class="row">
                        
                        <!-- Footer - About -->
                        <div class="col-lg-6 footer_col">
                            <div class="footer_about"> 
                                <!-- Logo --> 
                                    <?php 
                                        page_extends("app.logo_inner");
                                    ?>
                                <!-- /logo -->
                                <div class="footer_about_text">
                                    <p>
                                        Embarking on a journey of wellness and wonder. Embrace the unknown, and let the winds of change 
                                        guide you to new horizons. Life is an adventure—live it fully, with purpose and passion.
                                    </p>    
                                </div>
                                <ul class="footer_about_list">
                                    <li><div class="footer_about_icon"><img src="<?= asset_path("storage/images/phone-call.svg") ?>" alt=""></div><span>+1 (315) 617-3800</span></li>
                                    <li><div class="footer_about_icon"><img src="<?= asset_path("storage/images/envelope.svg") ?>" alt=""></div><span>info.naveenai.com</span></li>
                                    <li><div class="footer_about_icon"><img src="<?= asset_path("storage/images/placeholder.svg") ?>" alt=""></div><span>NAVEENAI Headquarters, NY 104, Oswego, NY 13126</span></li>
                                </ul>
                            </div>
                        </div>

                        <!-- Footer - Links -->
                        <div class="col-lg-6 footer_col">
                            <div class="footer_links footer_column">
                                <div class="footer_title">AI and Medicine</div>
                                <ul>  
                                    <li><a href="/our-research-papers">Research Papers</a></li> 
                                    <li><a href="/about-us">About us</a></li>
                                    <li><a href="/our-blogs">Blogs & Articles</a></li> 
                                    <li><a href="/faqs">FAQ</a></li>
                                </ul>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <div class="copyright">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="copyright_content d-flex flex-lg-row flex-column align-items-lg-center justify-content-start">
                                <div class="cr"> 
                                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> 
                                    All rights reserved. 
                                </div>
                                <div class="footer_social ml-lg-auto">
                                    <ul> 
                                        <li><a href="https://facebook.com/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="https://twitter.com/"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>  
                                        <li><a href="https://linkedin.com/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                        <li>
                                            <a href="https://instagram.com/">
                                                <i class="fa fa-instagram" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://youtube.com/">
                                                <i class="fa fa-youtube" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://github.com/">
                                                <i class="fa fa-github" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>			
            </div>
        </footer>

        <!-- local js script -->
        <script src="<?= asset_path("js/app.js") ?>"></script>
        <script src="<?= asset_path("assets/jquery/jquery-3.2.1.min.js") ?>"></script>  
        <script src="<?= asset_path("bootstrap/bootstrap4/popper.js") ?>"></script>
        <script src="<?= asset_path("bootstrap/bootstrap4/bootstrap.min.js") ?>"></script>
        <script src="<?= asset_path("assets/plugins/OwlCarousel2-2.2.1/owl.carousel.js") ?>"></script>
        <script src="<?= asset_path("assets/plugins/easing/easing.js") ?>"></script>
        <script src="<?= asset_path("assets/plugins/parallax-js-master/parallax.min.js") ?>"></script>
        <script src="<?= asset_path("js/custom.js") ?>"></script>

        <!-- include bootstrap js -->
        <script type="text/javascript" src="<?= asset_path("bootstrap/js/bootstrap.min.js") ?>"></script>

        <!-- local js script -->
        <script src="<?= asset_path("js/auth.js") ?>"></script>
        <script src="<?= asset_path("js/contact.js") ?>"></script>
        <script src="<?= asset_path("js/about.js") ?>"></script>
        <script src="<?= asset_path("js/services.js") ?>"></script>
        <script src="<?= asset_path("js/news.js") ?>"></script>

    </body>
</html>