

/**********
*
*   Returns Exceptions experienced
*
*
*
*****/