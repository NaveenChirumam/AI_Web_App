<?php

namespace App\models;

use SelfPhp\SP;

class HomeModel extends SP {
    
}