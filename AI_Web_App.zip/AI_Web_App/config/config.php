<?php

/************************************************ 
 * 
 *               ________________________________________________
 * 
 * 
 *                          S.P Framework v1.0
 * 
 * 
 *               ________________________________________________
 * 
 * 
 */

// Datetime zone
date_default_timezone_set("Africa/Nairobi");  

ini_set("upload_max_filesize", "12M");



