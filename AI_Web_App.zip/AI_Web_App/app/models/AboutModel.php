<?php

namespace App\models;

use SelfPhp\SP;

class AboutModel extends SP {
    
}