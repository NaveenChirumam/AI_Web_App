## ASSETS: JQUERY
- This folder stores the jquery js files.
- The files gets installed/updated as per composer install command is excecuted.
- the files get moved to this folder when the site get run by the user.
