

<!-- body -->
<div class="super_container">
    <!-- layout -->
    <?php 
        page_extends("app.layout");
    ?>
    <!-- /layout -->
	
	<!-- Home -->
	<div class="home">
		<div class="home_background parallax-window pt-5" data-parallax="scroll" data-image-src="<?= asset_path("storage/images/blogs-news.jpg") ?>" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content">
							<div class="home_title"><span>NAVEENAI</span> News</div>
							<div class="breadcrumbs">
								<ul>
									<li><a href="#">Home</a></li>
									<li>News</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- News -->
	<div class="news">
		<div class="container">
			<div class="row">
				
				<!-- News Posts -->
				<div class="col-lg-8">
					<div class="news_posts">
						
						<!-- News Post 1 -->
                        <div class="news_post">
                            <div class="news_image">
                                <img style="height: 10%; width: 100%;" src="<?= asset_path("storage/images/5-tips-ofAI.jpg") ?>" alt="Image 1">
                                <div class="news_date d-flex flex-column align-items-center justify-content-center">
                                    <div class="news_day">20</div>
                                    <div class="news_month">October</div>
                                </div>
                            </div>
                            <div class="news_body">
                                <div class="news_title"><a href="#">5 Tips for a Healthy Lifestyle</a></div>
                                <div class="news_info">
                                    <ul>
                                        <li class="news_author"><span>By </span><a href="#">Dr. Sarah Johnson</a></li>
                                        <li class="news_tags"><span>in </span><a href="#">Wellness</a></li>
                                        <li class="news_comments"><a href="#">5 Comments</a></li>
                                    </ul>
                                </div>
                                <div class="news_text">
                                    <p>Maintaining a healthy lifestyle is essential. Learn about five key tips for improving your overall well-being and living your best life.</p>
                                </div>
                                <div class="news_link"><a href="#">Read More</a></div>
                            </div>
                        </div>

                        <!-- News Post 2 -->
                        <div class="news_post">
                            <div class="news_image">
                                <img style="height: 10%; width: 100%;" src="<?= asset_path("storage/images/stress-management.jpg") ?>" alt="Image 2">
                                <div class="news_date d-flex flex-column align-items-center justify-content-center">
                                    <div class="news_day">18</div>
                                    <div class="news_month">October</div>
                                </div>
                            </div>
                            <div class="news_body">
                                <div class="news_title"><a href="#">Managing Stress in the Modern World</a></div>
                                <div class="news_info">
                                    <ul>
                                        <li class="news_author"><span>By </span><a href="#">Dr. Emily Roberts</a></li>
                                        <li class="news_tags"><span>in </span><a href="#">Mental Health</a></li>
                                        <li class="news_comments"><a href="#">7 Comments</a></li>
                                    </ul>
                                </div>
                                <div class="news_text">
                                    <p>Modern life can be stressful. Discover effective strategies to manage stress and improve your mental well-being in today's fast-paced world.</p>
                                </div>
                                <div class="news_link"><a href="#">Read More</a></div>
                            </div>
                        </div>

                        <!-- News Post 3 -->
                        <div class="news_post">
                            <div class="news_image">
                                <img style="height: 10%; width: 100%;" src="<?= asset_path("storage/images/Exercise.jpg") ?>" alt="Image 3">
                                <div class="news_date d-flex flex-column align-items-center justify-content-center">
                                    <div class="news_day">12</div>
                                    <div class="news_month">October</div>
                                </div>
                            </div>
                            <div class="news_body">
                                <div class="news_title"><a href="#">The Importance of Regular Exercise</a></div>
                                <div class="news_info">
                                    <ul>
                                        <li class="news_author"><span>By </span><a href="#">Dr. Michael Anderson</a></li>
                                        <li class="news_tags"><span>in </span><a href="#">Fitness</a></li>
                                        <li class="news_comments"><a href="#">10 Comments</a></li>
                                    </ul>
                                </div>
                                <div class="news_text">
                                    <p>Exercise is key to a healthy life. Learn why regular physical activity is essential and how it can positively impact your overall well-being.</p>
                                </div>
                                <div class="news_link"><a href="#">Read More</a></div>
                            </div>
                        </div> 

                        <!-- News Post 4 -->
                        <div class="news_post">
                            <div class="news_image">
                                <img style="height: 10%; width: 100%;" src="<?= asset_path("storage/images/meditation.jpg") ?>" alt="Image 4">
                                <div class="news_date d-flex flex-column align-items-center justify-content-center">
                                    <div class="news_day">25</div>
                                    <div class="news_month">October</div>
                                </div>
                            </div>
                            <div class="news_body">
                                <div class="news_title"><a href="#">The Benefits of Meditation for Mental Clarity</a></div>
                                <div class="news_info">
                                    <ul>
                                        <li class="news_author"><span>By </span><a href="#">Dr. Lauren Walker</a></li>
                                        <li class="news_tags"><span>in </span><a href="#">Mental Health</a></li>
                                        <li class="news_comments"><a href="#">8 Comments</a></li>
                                    </ul>
                                </div>
                                <div class="news_text">
                                    <p>Meditation can provide mental clarity and peace. Explore the various benefits it offers for your mind, body, and overall well-being.</p>
                                </div>
                                <div class="news_link"><a href="#">Read More</a></div>
                            </div>
                        </div>


					</div>
					<div class="news_page_nav">
						<ul>
							<li class="active"><a href="#">01.</a></li>
							<li><a href="#">02.</a></li>
							<li><a href="#">03.</a></li>
							<li><a href="#">03.</a></li>
						</ul>
					</div>
				</div>

				<!-- Sidebar -->
				<div class="col-lg-4">
					<div class="sidebar">

						<!-- Search -->
						<div class="sidebar_search">
							<form action="#" id="sidebar_search_form" class="sidebar_search_form">
								<input type="text" class="search_input" placeholder="Search" required="required">
								<button class="search_button"><img src="images/search.png" alt=""></button>
							</form>
						</div>

						<!-- Categories -->
						<div class="sidebar_categories sidebar_section">
							<div class="sidebar_section_title">
								<div class="sidebar_title">Categories</div>
							</div>
							<ul>
								<li><a href="#">Medical Articles</a></li>
								<li><a href="#">Therapy</a></li>
								<li><a href="#">Useful Information</a></li>
								<li><a href="#">Uncategorized</a></li>
							</ul>
						</div>

						<!-- Archives -->
						<div class="sidebar_archives sidebar_section">
							<div class="sidebar_section_title">
								<div class="sidebar_title">Archives</div>
							</div>
							<ul>
								<li><a href="#">December 2017</a></li>
								<li><a href="#">January 2018</a></li>
								<li><a href="#">February 2018</a></li>
								<li><a href="#">March 2018</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div> 
<!-- /body -->

<!-- footer -->
<?php 
    page_extends("app.footer");
?>
<!-- /footer -->