<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="origin">
    <link rel="shortcut icon" href="<?= asset_path("storage/favicon.ico") ?>" type="image/x-icon">
    
    <title><?= app_name() ?></title>

    <link href="<?= asset_path("bootstrap/css/bootstrap.min.css") ?>" rel="stylesheet"> 

    <!-- font-awesome icons -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/6a9db0427a.js" crossorigin="anonymous"></script>

    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500&display=swap" rel="stylesheet" />

    <!-- <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css"> -->
    <link href="<?= asset_path("assets/plugins/font-awesome-4.7.0/css/font-awesome.min.css") ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("assets/plugins/OwlCarousel2-2.2.1/owl.carousel.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("assets/plugins/OwlCarousel2-2.2.1/owl.theme.default.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("assets/plugins/OwlCarousel2-2.2.1/animate.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/main_styles.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/responsive.css") ?>">

    <!-- contacts -->
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/contact.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/contact_responsive.css") ?>">

    <!-- about -->
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/about.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/about_responsive.css") ?>">

    <!-- services -->
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/services.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/services_responsive.css") ?>">

    <!-- blogs & news -->
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/news.css") ?>">
    <link rel="stylesheet" type="text/css" href="<?= asset_path("css/news_responsive.css") ?>">
</head>

<body class="bodyContainer">
    <?php    
    if (Authenticated()) {   
        ?> 
        <!-- auth navbar -->
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a class="navbar-brand" href="#">SP</a>
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Documentation</a>
                    </li>
                </ul>
                <ul class="navbar-nav  mt-2 mt-lg-0 pr-4 pl-4">
                    <li class="nav-item">
                        <a class="nav-link" href="#"> <i class="fa fa-inbox" aria-hidden="true"></i> Inbox</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-user-circle" aria-hidden="true"></i> 
                            <?= Auth('username') ?>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="#">Profile</a>
                            <a class="dropdown-item" href="#">Settings</a> 
                            <a class="dropdown-item" href="/logout">Logout</a>
                        </div>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="text" placeholder="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
        <!-- /auth navbar -->
        <?php 
    }
    else {
        ?>
        	<!-- Header -->
            <header class="header trans_200">
                <!-- Top Bar -->
                <div style="background-color: green;" class="top_bar">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
                                    <div class="emergencies  d-flex flex-row align-items-center justify-content-start ml-auto" style="background-color: red;">Artificial Intelligence</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Header Content -->
                <div class="header_container">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="header_content d-flex flex-row align-items-center justify-content-start">
                                    <nav class="main_nav ml-auto">
                                        <ul>
                                            <li><a href="/">Home</a></li>
                                            <li><a href="/about-us">About us</a></li>
                                            <li><a href="/our-research-papers">Research Papers</a></li>
                                            <li><a href="/our-blogs">Blogs & Articles</a></li> 
                                        </ul>
                                    </nav>
                                    <div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Logo --> 
                    <?php 
                        page_extends("app.logo_outer");
                    ?>
                <!-- /logo -->
    

            </header>

            <!-- Menu -->

            <div class="menu_container menu_mm">
                <!-- Menu Close Button -->
                <div class="menu_close_container">
                    <div class="menu_close"></div>
                </div>

                <!-- Menu Items -->
                <div class="menu_inner menu_mm">
                    <div class="menu menu_mm">
                        <ul class="menu_list menu_mm">
                            <li class="menu_item menu_mm"><a href="/">Home</a></li>
                            <li class="menu_item menu_mm"><a href="/about-us">About us</a></li>
                            <li class="menu_item menu_mm"><a href="/our-research-papers">Research Papers</a></li>
                            <li class="menu_item menu_mm"><a href="/our-blogs">Blogs & Articles</a></li> 
                        </ul>
                    </div>
                    <div class="menu_extra">
                        <div class="menu_appointment"><a href="#">NAVEEN AI</a></div>
                        <div class="menu_emergencies">For Research Guide: +1 (315) 617-3800</div>
                    </div>

                </div>

            </div>
	
        <?php
    }
    ?>

    