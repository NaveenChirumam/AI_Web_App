
<div class="footer_logo_container">
    <a href="#" class="d-flex flex-column align-items-center justify-content-center">
        <div class="logo_content d-flex flex-column align-items-start justify-content-center">
            <div class="logo_line"></div>
            <div class="logo d-flex flex-row align-items-center justify-content-center">
                <div class="logo_text">NAVEEN<span>AI</span></div>
                <div class="logo_box">+</div>
            </div>
            <div class="logo_sub">Artificial Intelligence</div>
        </div>
    </a>
</div>

