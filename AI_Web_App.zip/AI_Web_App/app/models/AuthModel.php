<?php

namespace App\models;

use SelfPhp\SP;

class AuthModel extends SP{
    
    public static $table = "users";

    public function __construct()
    {
        
    }

    
}


