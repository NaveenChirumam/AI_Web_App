
<!-- layout -->
<?php 
    page_extends("app.layout");
?>
<!-- /layout -->

<!-- body -->
<div class="super_container" style="margin-top: 8rem">
	<!-- Home -->
	<div class="home">
		<div class="home_slider_container">
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(<?= asset_path("storage/images/AI_Logo.jpg") ?>)"></div>
					<div class="home_content">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_content_inner">
										<div class="home_title">
                                            <h1 style="color: green"> AI in Medicine</h1>
                                        </div>
										<div class="home_text">
											<p style="color: white">
                                                Revolutionize Healthcare with Cutting-Edge AI: Empowering Patients, Streamlining Processes, 
                                                and Advancing Medical Science for a Healthier Tomorrow.
                                            </p>
										</div>
										<div class="button home_button">
											<a href="/blogs" style="color: white">read more</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Slider Progress -->
			<div class="home_slider_progress"></div>
		</div>
	</div>

	<!--Our Services --> 
	<div class="about col-lg-10" style="margin: 0 auto;">
		<div class="row">
            <div class="col-lg-12">
                <h3 class="section_title">Problem and Solution</h3> 
            </div>
            <div class="col-lg-12">
				<h5>Problem:</h5>
				<p>
				In the realm of modern healthcare, one of the prominent challenges we face is the timely and 
				accurate detection of diseases. Often, critical diseases manifest with subtle symptoms that are 
				difficult to identify in their early stages. This delay in detection can significantly impact 
				the effectiveness of treatments and overall patient outcomes. Additionally, the sheer volume and 
				complexity of medical data generated daily make it humanly impossible for healthcare professionals 
				to analyze and interpret all this information swiftly and accurately.
				</p>

				<h5>Solution:</h5>
				<p>
				Artificial Intelligence (AI) offers a transformative solution to address these pressing issues. 
				By harnessing the power of AI, we can develop advanced predictive models that can analyze vast 
				amounts of health data efficiently. These AI models, fueled by machine learning algorithms, can 
				identify intricate patterns and subtle anomalies within medical data, enabling early disease detection. 
				Leveraging sophisticated algorithms such as Convolutional Neural Networks (CNNs) and Recurrent Neural
				Networks (RNNs), these models can sift through imaging data, genetic data, clinical records, and 
				other sources to detect potential diseases at their earliest stages.
				</p>

				<p>
				By integrating AI into the healthcare system, we can design a more proactive approach to patient care. 
				Personalized treatment plans can be formulated based on the individual's health history, genetic makeup, 
				lifestyle, and environmental factors. AI-driven recommendations can optimize treatment regimens, 
				medication dosages, and surgical interventions, tailoring them to suit each patient's unique needs. 
				This not only improves treatment outcomes but also minimizes adverse effects and enhances overall 
				patient well-being.
				</p>

				<p>
				Moreover, AI doesn't just stop at early disease detection and treatment planning. It extends its 
				benefits to reducing the burden on healthcare professionals by automating mundane and repetitive 
				tasks, allowing them to focus more on direct patient care and complex medical decisions. This, 
				in turn, enhances the efficiency and productivity of healthcare systems, ensuring better utilization 
				of valuable human resources.
				</p>

				<p>
				In essence, AI in medicine represents a paradigm shift, augmenting human capabilities and 
				amplifying the potential for better healthcare outcomes. By embracing this technological 
				advancement, we pave the way for a future where healthcare is not only more effective 
				but also more accessible and patient-centered.
				</p>
            </div> 
			<!-- <div class="row pt-5 col-lg-10" style="margin: 0 auto;">
				<div class="col-lg-4 w-100">
					<div class="image">
						<img style="height: 100px; width: 100px;" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAH4AdQMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABQEHAwQIAgb/xAA9EAABAgQBBwgIBgIDAAAAAAABAAIDBAURBhIhMTZBUXEWMlV0kZOxsgcTFCJhgaHRF0JTkpTSFSNScoL/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAgQFAwEG/8QAIBEAAgIDAAIDAQAAAAAAAAAAAAECAwQREiExExVRFP/aAAwDAQACEQMRAD8Au5jRkjMNG5eskbh2KGc0cF6QEZI3DsRkjcOxaVRrFNpYaajPS8tlc0RYgaTwCX8ssN9NyXehAPckbh2IyRuHYkXLLDfTcl3oRyyw303Jd6E0B7kjcOxGSNw7Ei5ZYb6bku9COWWG+m5LvQmgPckbh2IyRuHYkXLLDfTcl3oTGnVenVRrnU6el5kN0+qiB1uKA3Mkbh2IyRuHYpCEBGSNw7EZI3DsUoQGKKBmzDsQpi7FCA9s5o4LTrc+KXR5yfLcr2eC6IG7yBmC3Gc0cEkxzqfV+qv8EBQMzHnqxUnR5hz5mdmX2zC5cToAHgFu8lq/0LP9w5GENaqR1uH5l0cpt6IJbOceS9f6Fn+4cjkvX+hZ/uHLo0pFUsXUemTkSTnJiI2NDtlBsFzhnF9IC9j1J6SPJcxW5Mo/kvX+hZ/uHI5L1/oWf7hyvGl4spFVnGyklHiPjOBIBhObo+JCeJLqL00I8yW0znLktX+hZ7uHLTkpydo1SbMyrny85LvtnFiCNLXDdsIXTK5sxNrJVuuxvOUT2etaOiaVONqFNlJ1gyWzEFsQC+i4vZbaT4O1VpHVIflCcLmTBCEIDHF2KFMXYoQHtnNHBJMc6oVfqr/BO2c0cEkxzqhV+qv8EQKOwhrVSOuQ/FdGrnLCGtVI65D8Ve+LJiNK4eno8tEdCish3a9ukG4U2tySIb5i2NdKp3HutU7/AOPIFqnEtc6Vmv3pdNTMebjujzUV8WK7nPebkrUxcWVM+mzMycmNsdJH0Ho81ql/+j/KreVBSk1MScdseUjPgxW6HsNiFv8AKWudKzX70ycSVs+kxj5UaoaaLuXNuJtY6t12N5yr+wvHizWH6fHmIjokWJAa57naXG2lUDibWOrddjecrLS1Jo029xTL7wfqrSOqQ/KE4SfB+qtI6pD8oThQJghCEBji7FCmLsUID2zmjgkmOdUKv1V/gnbOaOCSY51Qq/VX+CIFHYQ1qpHXIfir8xFIxalRZuTlyxsWNDyWl5IF/jZUHhDWqkdch+K6OU29NNEEtx0yqvw6rX69P71/9F85VqdHpU/FkpkwzFh2yjDJLc4vtA3q9iqdx8Ryrnc4/J5AtLEybLbOZGdlY8K4dRNzBOG5epsjVGpm0jANsm9g8gXNzuAsnIr+DI8b2J1Na2ATkiO6XaGcb3yhxsowaBVcEVCmQHAR2+sbp/5C7ft8lXhBBLXCxBsQRoK9jD57JdN+PRFz+GEeV7L6p8rBkZODKywIgwmBrATfNszrnXE2sdW67G85V3YCqn+Rw/BbEdeNLf6X3+A909lvqq6r/o+xHMVafnJeVgRYcaZiRGBsdocWlxI02WbJOE2pGjGSlBNFpYP1VpHVIflCcJZhqXjSeHqdLTLMiNClmMey4NiALhMrrmdSUIQgMcXYoUxdihAe2c0cEkxzqhV+qv8ABO2c0cEkxzqhV+qv8EQKOwhrVSOuQ/FdHLnHCGtVI65D8y6OUpEY+iFrxqfJx4hiRpSXiPOlz4QJPzWyhR3o9aTMEvJy0tlGWl4MIu0+rYG37FU2PaZ/jsQRXsbaDNf7mbrnnDtz/NW+SvlfSHTBP0F0xCGVFlD60W2t/MOzP8lZxbeLU36ZWyq+6/HtFe4exBN0F8y6Vax/r4eTZ+hpGh3x29qzNxhiBsQvFSeb7DDYR2WSJC2XTW2215MlWzS0mfYSnpDq8FwEzBlphm33Sx3aDb6L6/DmMJCtxxK5ESXmiLiG/OHW02KqBbtFmvYqvJTN7CHHYTwvY/RV7sOtxbitMsVZVkZJN7Re6FF1KxTYMcXYoUxdihAe2c0cEkx1qfV+qv8ABO2c0cFq1iRbU6VNyLzktmIToeVuuNKA51oM5Dp9bkJ2OHGFLx2RHhouSAbmytv8VcP/AKU/3Tf7KoKrTZyjzz5KowTBjMOg6HDe07QtO66a2c96Lr/FXD/6M/3Tf7KR6VcPEgGHPNvvhN/sqUvmUEgixsnKPemXd6T56agU+Tgy73sgTDnetc02yrAWb87k/JV5Iz83IE+xzESEHCzmtPuuHxGgr6HDWO6VOUdlHxbDJEMBjJgtLmvA0ZVs4cN4+iZzWCadU5b2zDFRhxGHQxz8thO7KGcfO6u419cIcTRRyaLJS7gz4ICwAGxC2qjT5umzJl56A6DFGeztBG8HQVqrUi01tGc009MEHOLIQvTwvaizPttIk5nbFgMceJGdby+V9HE6JjDcOAXXfLRHMdwJyh9Db5L6pfOWR5m0b9UuoJmOLsUKYuxQoHQ9s5o4L0vLOaOC9IDXm5KUnWBk5LQY7RnDYsMPA7VqcnqJ0RT/AOMz7JmhALOT1E6Ip/8AGZ9kcnqJ0PT/AOMz7JmhALOT1E6Ip/8AGZ9lnk6XT5F7nyUlLS7nCzjBhNYTxsFuIQC6s0iUrEm6WnIeUDzXjnMO8FVXNYOrsCZiQoUhEjMY4hsVhbZ436VcqFYpyZ1eEV7saFvllK8k8QdFRv3N+6OSeIOi437m/dXUoXf7Cz8Rx/gh+srvAdOrdIqzxNSEaHKTDMl7iWkNIzg6eI+asQIUqrba7ZdMtVVKuPKMcXYoUxdihcjoexcACwU59ylCAjPuCjKz2zX4qToSV9GmMt0SHU47IjgWkjKOYkkfm2XzHhwQDm53BF+CSwaFEgxGllRmGsuCWNe8Xs1rdOVub9UOokybllVjsLm2LgXX0kjS7dm7dtiAHQN9Fu1FzuSqHSo8OA6GyoRAHRjFJANxe9wPe0Z78dN9CmTpUeBFbEi1KYi2cSWlzskgttaxJ2576UA0udyLnclc3R2Tcy2JEi+6BDzZPvEtJ0m+0EjRm06VrxcOtcGNhxocJgsXBkG13AuN8xzZ3kgbPjoQDy53IyjuSE4baIbWQ5p2SAWlkSGHNALg73bWLTm03271s0yjmQmfW+1F7TDyPV5GS0Z9IF8287ySdwADbPuRn3KUIDG9pdbMELIhAf/Z" alt="">
					</div>
					<h4 class="font-weight-bold pt-3">Health Information</h4>
					<p class="pt-3">
						Delve into a vast reservoir of meticulously curated health information, leveraging the power of artificial 
						intelligence to provide comprehensive insights into medical conditions, wellness strategies, treatment 
						options, and the latest advancements in the healthcare domain, ensuring you have the knowledge you need to 
						make informed decisions about your well-being.
					</p>
				</div>
				<div class="col-lg-4 w-100">
					<div class="image">
						<img style="height: 100px; width: 100px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAACLCAMAAABmx5rNAAAAt1BMVEX///82mdylxjsqf7j///3m5ub6+vrp6emkxjj///ugwyqjxTQqlduixDApfbQxl9z6/PLN350bkdqyzFz1+OqoyEXr9fkUeLUAbq/w9uHQ5fKMv+Xx8fG91Hmqyk3X5aycwRbb6LmPuNY7irvp8NXF2o0thsKnz+xqreC603LB14O00Gbf6cJOpOExkM8AiNjA3/R4tuW60eFgncff6vGfwdlOk8BxpswYiMyAr9Kbyey31OycxpxOX61RAAAKP0lEQVR4nO1aC3eiSBMF7GFoaEQ7PCJG1AQVHxjNkDiR/f+/a6u6MeAjs3s+yMx3zlLn7I6JHfpSdavqVoOitNZaa6211lprrbXWWmuttdZaa639Hxr50wBobwDm9ugfQ4AuoG7cH915mmEZhqFFd6Nx7P4BRABl0F96E9NGGGjwr21OtHXf/d1A3HE0MSUIzRBATj/Yk2j8O+G4M08CMWzb1jwviiLP02xwEv7Ssr3Z70FDlF7fRiSGZU6i1XiDtKW05w424xUGDeGYVr/3G7KKTi0LkZjWcuxebkfc8dISQE1t+sU0Joo7MgU1jP6A4M+EEEV/8P0HnVKC0Migr0k0oy8NFFE2lokhiMbypv2Xxx9PQXAP1n368fiSid/2+oJOpr35ujhRpY9ssDQgAwDLXt86QRB0Toaf314zCvv3ZoaFzO4r9EvQwEVnE4jP5C7Gz+EBNu92u52ucMv9vQQVdA4hfh1H4BrDnH0FEjA6miAN+ogrfLoHIPP59qe6z0Pf98OXx6fCRfdPITJnhhlujsgXUJgqSxPjs4HP/qEbdDvbraqqCx/ZK1jr7+bzTqeLzjn4QOQpktxeyi8bNTKbIJQBBOAFkMy3jqpyNazuQ/yEzyWY7gv8PLCBNF8Rpj54xY5chdJ3QKJK8y8SRU+YM5e8eUQwEYap3zSUDUTfAK8o+uF+vpVIWH61LOOqukU03eCgAxgRprhZKK6FVwUo/ltwcoqTXpcPMgQw6lbE6c2nECa4BavJokfoCHm7Uaj+FhROAbZcuwWKjvxOhOkNPDOFimSPmsylqSmSmeiHEoqqZjdW6on8bi7SCcDM4C7MaXMFGCNk3cGHx6BEoqb6rbVDtQLmETBEFkSp1xQUpQ+d2QIGhlUozv7mvR55FQykdgyJbTeWSy4QcAJX87vsH7GQxQmL4EzHl1HSmqIvXswDbXT4qf6zX0osW3TMOzRKz8Ai0wRjiAvX0sAt4dz5N1hK34nUDhXs7kbUhGOIMsZ8hqx8OoOiOslt7lZWAWWCJxClUCXNcSNY7izRVMKf51jU1L+1fl9dhV07FEG2ogawKAPsiSBZDuwCy8364ifVVXOI0kGkkjFpIkjQFO0lUbLtBRKV7W6szs6WCMZkCllajQSJFtd55ZdY+PB6NcnZ2RpwTPAq7sda1k8kzKIJqJb0EgrYdZshyXkg0TFvMD1MNMOrH6QYL3Pp+1OQrm7VVy+SDZVeRhQcHupLB8hoe3Tle7nR/soxi8tlW9kImiHMytbssUKON7CoLLxY7F9HUko8vKNVbSxrS4OZi+4vE1o4JrlwzOKK4IjlB8hCEB13daHoQF0Dqkt6C4vKFhXGUBLeWAJi/IkqMVyldrWD+m14A0VXb/qFsbCcOIivXpVDkUkBFEyYrLy66s6FG4IerV8533EYT/dMhVySQ74SptzZO5xdY9GVgQdDbd2kHqBze4p/TYR97pOQOzwRBCbZEFCkir4bogsr/gEsD0I3NIFFi+g5FsbBKYgAsMBPLB0ej4kq/IF/4gO3mOOUWO59gcUY1MUCCvHcLw5P85wzv8ACjuEOg/87ACbFP9FTNtwlvODOtjksPWjSUZUvLAG6hoxlEouThiTn2JtggJVY/JQvCMRMegpj5GMnMbS6ApxqYlwkBQOcdEeJyJhch6E9fE4yQkHj7mHC16G6EJFOPCc6oEkY/JXT7XSJyCOt9pQUGYaoL9IpqS4uuANG8BwKylBmdCgkHsn2inAWk8qG7rmDfnmCrgYjm1cTiVB1lbqbiTOhEG+YsSEl4tiJkEJYy1ozZFLxEYIs3nYbq7vYj8xTP2JDefY+hBoXpowPryUJAmAfwmbHEcujFGR1+xE59ekdwwwKJZYU+KHQhPPUJ+erAcuRPX/8Vkc1VfTpSf0+HZveSb84xdSqq3yBkLC6nelvf7cIQ8aTExQC0mouRCZOAvX1iwvzMOg6BQQbK2Licy6l7hG4WTmZ2qmcAzxg7ul3ALeD1B00o+uUpZj6UA4UCBSocFK4kBwEeX7aeAfIUsepHIUQCG230LvGqIFzOyCMsaYkg1JRDCEL/jEaQdFzcplMNGFp6O9UVpXk2RZDRNcNDWugmy0txqw+6ds9KxmRpbxIJ99hOQTnyKpnIbmcj6C6wHzUwESNc+NK9J5il4Tty2/9hHERsQyjc46F6OlpbrTrVxeR1XBXRg9KLxObQb9hx1JAEf1UT1KcakOVVWb+RdB9g56G52RNhAguFcmD0dCRdTdT+dmxbiJ2JxQKGwc5wbOPLMq2QQeWzmyhxxoxcDE2WUhQFXaFJl1uBxvuHH5U0EE0Z5yh0PvAkszx/AV7dGOHvC5Wqhk04FQUuZw7ehmj/JlxSRAo//kiLysxOf7sdE/nUo0d2PWLE9VQzIpDnpRYgCBJVu2MH9lCdlyMaRtQY1ZzZ98UhJDliTIKlDnytIQCzvhEloTqXBzEe1YT0qW06UQ+ZCCgSPhC5cli6P+6jJKMb4N3Skhxvtuc0RXQ15pCwUiYA7KKs+f810/Mduo2+EFE1W5krK+YoC+WKx1UrZMmSJLPsVAKM37wA1gVi+fYDT+3iS1zRMVz1yHI/r2v/IoBGYwGwTuAje3icX5zjx3JYr//667YnSIY9RchogvV2XYeYUHs2RKKuWkKioK7Q2UR7RjVP0wbPN3pN9HoCxhlfz6hAoztAgroy4b8Ip4JbecBCpXe3Rhb3hDGQp4es8sTXj07psxh83f4go5PL19ozZ3BD5k4XkLd2lubKKHFHA/ylyXHUMyPFOOnh0cYHh32/CR0zqoKxWzksTkZPsuj/U4neI2wWEQbLHHh0IGx2nkGAZ7s9/skRX0Js+z2XUjMjWd6JRTDXtZHUnilK7B07//Cx/GWtRK6KFskUGgAj8PAHPSTmuSiIbgry9KqJh5V1jOiCK5IKJ1u5xBr2LNt+RYBBeF/3KeouPG8Y3/ciYfVSm+mVeMjg1S/9Aoo5RsLB6W3suUbJ6u4yHFQU/qD/pFUNF5ZYoll2xVA9XVdQduT3UPbJRv5TpBprsVrJ2dGBv21LZ4em9omBveUcCb1VAOpBkg8PhR707EMgWFOrHV/Gg8GvZ7rDuJpf6lNim+0PnqNbmbe5FTuxjUyidDzAAEUOXwANftR8UYOBsLQIs/zNPhoCS/YdiToJARNbzPyTOSxta6jGyBATjVAj5X76k3vJqZ1enes8hqZZU7upufhcKdrcFedJ+b0eBmg0seiRffGI882bXxcLOBArpu2N7p+oY1gWJdeDWkHw7xzzZVzuG48Xa0jqGngIS9ar6afv3dIXfI/z7B4FHfGlc+ZR4G5H69jfrIjUeq8BpOpzhmUP2kwbFRo+0dfh4W986DkymdQ9HP7OjgFmJIrsNsD2Hdp377hf1X7Xhque2gQHcnvuxiggpb6xc7/yr43huZlHnReyx/P3PIJsu/fCr98F45pCgmeb4TZbdrqv7SmELTWWmuttdZaa6211lprrf037W9+6NvG217RaAAAAABJRU5ErkJggg==" alt="">
					</div>
					<h4 class="font-weight-bold pt-3">Doctor Timetable</h4>
					<p class="pt-3">
						Experience the seamless orchestration of healthcare services through our sophisticated AI-powered doctor timetable system, 
						intelligently optimizing schedules, synchronizing appointments, and ensuring efficient allocation of medical 
						professionals' time, ultimately enhancing patient access and facilitating a smoother healthcare experience for all
					</p>
				</div>
				<div class="col-lg-4 w-100">
					<div class="image">
						<img style="height: 100px; width: 100px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAMAAAAOusbgAAAAZlBMVEX///8AAABzc3OMjIyGhobT09Ompqbv7+8PDw/29vZZWVlcXFwuLi49PT21tbWtra3o6OhGRkZMTEwXFxfZ2dnBwcF6enri4uKenp5SUlKUlJS7u7tjY2M4ODjJyckbGxsnJydra2vp2g05AAAGJklEQVRoge2b2daiOhCFDXMEFBBkEBHf/yU7IQlkZBL7nNXLffW3knyhqKpUBft0+umnn7CS3HXz0v+rTFh6bRa9guDWP2vr8bfg0EuBqPflL2CTO9DpCr/MrXotF4Bn902snxmwWPb3uIUAiuuwfgo3/S0vu4yIIKvyxIcQ+olrT64Wl1/hdiPAycUvzl+955H7TpTvXGby/njnTtjcV923kAXZ/XBwS2cuDN9X9HucS8pL1TTV9ZAn/iDT3nLjFR41dvGe/DwsPjU9jMlMc1nC1gV3+mE2pZHkzF6kzy6h6ovrRW84nTdcogUb3HGdunnHYtLvH8Th9onMmC15Sh5Q0tOqKieeyI+94LUmc/BlsccWeKkZ2d3Hzcno5dCA9jO2uctgRW3w3AcmPh2tuVReXBfscrCy8KwsupGxzbaxbAoy+LV++4Blkwnlxk4PuW685S6Ug2IpmEwiHlavu/gRqdG4t6hyia3NWX5SYmmyQL839cF0rcE6bSW5P/EN0Q2qxesqjlbbXpGXeXf1Pkj1xL3e69aHlXrJIZUMKU7PC1eNiT7e68UG8IJbs9088I7CrjP1gz3bIyvkZphyttFIXoR7PrRKbZfDiW6hYo1aWuft4u6PZmvgmK1IK6tWvF+hP1qtKWw99tHLMRgSUoT09S4uVxdyeSHW5026NDkno49u0TYJ4OSmNQR3w+QJW/Ln6LO3v0lQAJ/yOpol01JScQHdYhYEpBI8KcaGEqgJgmzAarjtA4cXrKnIm3Y8ZbchH6uPfx8YKA5zYZuetN/Q/Vo7iwguu25hV9c5NyJQciteXJmevQguaIcUzx0w6cEnn/q32Fk42liSwG49zfmUkiAUhtz9pAjkNo8Wu0IPBocpdZURBxaPfcRZu2fOD7FJRyP1lzSZ8Ev2h7QVa+w3gcn+di4ej8JWyA5X/xKwq4Jpyck3FsT+mcqdwC4x1J27d+5phVzFbwbTcVx5T5pbXZkwgmkq58H9NEOEtvoyLBfAav+3DGZFAg8W7jJG5q6WwI38jJJgCcxSj7AKMFwCu+Gy05vOOAMmibmefMnvF5zLR9WJVTVNM7hkjv6ocAQOtnVAiS2GXIfs5TPgspceERwSQ6+pEii4BEr5klD3Qr2Ch++kjEHkL4DpHsilTWJJcwLBKVVqGPFaorrGC7hfQAA8dDd+GafZDJieDXHgRna3dWBsB+RpYQUyYCFSSXOEEVzLYOKnmrZ/wdQJuL9RSghBBSLQA++NgnQOnMrgkxLaIhhT7lfP84anUaI/PGwk91S/bqBFhsZP2QFhn8E5MMmQAQ9OpcCUwJB16nI4IdtGqD7t8RFNgRbgzDoXSX/CwTYpbtXDCsa66hIImhhVWE2Hm48eBCVxhBkwWbHQz/gR8wo9+KQBB/lgqiK/AQsFZIQrZDjuTjcNuNXYlezIgRzKI/iigodVug5EQBsFZHZ6DzXMDJgGgvAZLRB6E5hGXOt2XUf/HC86oyxto39Xw1rM4IZ5hqBqfG56sHwkzWX2O0phDRrppu4cOOkno6l2kJ4AB576INkbSgui/F9MQ/Rg2vYrR5su7z868Ak2tCvo7zOnIiYwNWmrjmgYmQsqIJa3fnlpGi+fPSI0gFkM6opj9rIlnqwBdhX0GjBLBPoXDOOLBYut6yCw/6YTG46Q/fEM89W6bHP9HJxUrGPsTV0IZNZGiu5eBz8CD56fX7m3FTNHouoLJAqunHmNLjmBFc12XV2sB8+9th7EIswIThdeTkDppilY/lHCZvB9+ZweNi8V/LguiNWoenC47l2Mf2l7CbxaGnDfbngFVBZVdjsCnDrdjmPnj8CO8kJoD9hKM73SShliKgR2gc3hZCtDDgWbw+nL4MQoXxlyKHjLkH8D7JttTaRmrm97NVU1Dfk3wFacziq+TkMw+PVfOdcPvBtcXBblfgW8WPow0NHgxXBiu8XR4MZa1OUr4C1DfuB94K2/PTwM3Ieb1B4G3qEDwMEyRaPmc3CRxkj47PMVr1bmfw5GHRxS3mPnhmuFh30OxsLvEjY6d3kYuMbH1etlaw/K94B36HNwsg98wA/r7WCHnkf8dCd3t+vb/3vip5/+b/oDMJVnJDRA/xYAAAAASUVORK5CYII=" alt="">
					</div>
					<h4 class="font-weight-bold pt-3">Medical Information</h4>
					<p class="pt-3">
						Embark on an enlightening journey through a wealth of AI-driven medical information, meticulously curated and presented 
						to empower individuals with a comprehensive understanding of diseases, conditions, treatments, medications, 
						and breakthroughs in medical science, all aimed at fostering a deeper awareness and fostering informed choices 
						in managing health and wellness.
					</p>
				</div>
			</div>  -->
		</div>
	</div>

	<!-- About -->
	<div class="about col-lg-10" style="margin: 0 auto; margin-top: -3rem;">
		<div class="row">
			<div class="col-lg-12">
				<div class="section_title"><h2>Aims and Scope</h2></div>
			</div>
			<div class="col-lg-12">    
				<p>
					The Aims and Scope of our initiative encompass a comprehensive vision for harnessing the 
				potential of Artificial Intelligence (AI) in the domain of healthcare. We strive to:
				</p>

				<h4>Advance Medical Research and Development:</h4>
				<p>
					Our primary aim is to foster cutting-edge research in the field of AI and its applications 
				in medicine. We aim to contribute to the growth of medical knowledge, technologies, and 
				methodologies that can positively impact healthcare practices globally.

				</p>
				<h4>Empower Early Disease Detection and Diagnosis:</h4>
				<p>
					We aim to develop AI models that excel in early disease detection and accurate diagnosis. 
				By leveraging AI algorithms and machine learning, we seek to enable timely interventions, 
				ultimately enhancing patient outcomes and survival rates.
				</p>

				<h4>Optimize Treatment Planning and Personalized Care:</h4>
				<p>
					We aim to revolutionize treatment planning by employing AI-driven recommendations. Our goal 
				is to personalize healthcare, tailoring treatment plans to individual patient profiles, 
				thus maximizing treatment effectiveness and minimizing adverse effects.

				</p>
				<h4>Enhance Healthcare Efficiency and Productivity:</h4>
				<p>
					By automating routine tasks and streamlining data analysis, we aim to ease the burden on 
				healthcare professionals. This will allow them to focus more on direct patient care, research, and complex medical decisions, ultimately leading to a more efficient and productive healthcare system.

				</p>
				<h4>Ensure Data Security and Ethical Practices:</h4>
				<p>
					We are committed to prioritizing data security and privacy. Our aim is to adhere to the 
				highest ethical standards, ensuring the responsible and ethical use of patient data while 
				maintaining compliance with legal and regulatory requirements.
				</p>

				<h4>Educate and Raise Awareness:</h4>
				<p>
					We aim to educate healthcare professionals, patients, and the public about the potential 
				and limitations of AI in healthcare. We intend to provide clear and accurate information, 
				fostering awareness and understanding of how AI can be harnessed to improve healthcare 
				outcomes.
				</p>

				<h4>Foster Collaboration and Innovation:</h4>
				<p>
					We strive to cultivate a collaborative environment, encouraging interdisciplinary research 
				and partnerships between medical professionals, data scientists, AI experts, and technologists. 
				Through collaboration, we aim to drive innovation and accelerate advancements in the field.

				Our scope encompasses a wide array of topics, including but not limited to AI-based 
				diagnostics, predictive analytics, medical imaging analysis, drug discovery, patient 
				management systems, telemedicine, and health informatics. We aim to continuously 
				expand our scope to embrace emerging AI technologies and their applications in medicine, 
				staying at the forefront of the rapidly evolving intersection of AI and healthcare.
				</p> 
				<div class="button about_button">
					<a href="/blogs">read more</a>
				</div> 
			</div>
		</div>
	</div>

    <!-- our services -->
    <?php 
        //page_extends("partials.our-services");
    ?>
    <!-- /our services -->

</div> 
<!-- /body -->

<!-- footer -->
<?php 
    page_extends("app.footer");
?>
<!-- /footer -->