<?php

namespace App\models;

use SelfPhp\SP;

class ContactModel extends SP {
    
}